package com.example.test.pert4.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.test.pert4.Model.UserGame;
import com.example.test.pert4.R;
import com.example.test.pert4.Repository.MyGamesRepository;

import java.util.ArrayList;
import java.util.Random;

public class ListViewHomeAdapter extends ArrayAdapter<UserGame> {
    MyGamesRepository myGamesRepository;
    ImageView imageView;
    int prevPlayHours, playHours;
    TextView tvGenre, tvName, tvDesc;
    Random random;

    public ListViewHomeAdapter(Context context, ArrayList<UserGame> listGame) {
        super(context, 0, listGame);
        myGamesRepository = new MyGamesRepository(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final UserGame games = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_home_listview, parent, false);
        }

        tvName = convertView.findViewById(R.id.list_gameName);
        tvGenre = convertView.findViewById(R.id.list_genre);
        tvDesc = convertView.findViewById(R.id.list_desc);
        final TextView tvPlayHours = (TextView) convertView.findViewById(R.id.list_playHours);

        tvName.setText(games.GameName);
        tvGenre.setText(games.GameGenre);
        tvDesc.setText(games.GameDescription);
        tvPlayHours.setText(games.PlayingHours);

        imageView = convertView.findViewById(R.id.list_image);

        imageView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                prevPlayHours = Integer.parseInt(tvPlayHours.getText().toString());
                random = new Random();
                playHours = prevPlayHours + Integer.parseInt(String.valueOf(random.nextInt(10) + 1));
                myGamesRepository.updateData(games.MyGameID, playHours);
                tvPlayHours.setText(Integer.toString(playHours));
            }
        });

        return convertView;
    }

}
