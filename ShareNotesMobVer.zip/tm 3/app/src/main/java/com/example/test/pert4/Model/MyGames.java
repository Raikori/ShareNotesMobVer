package com.example.test.pert4.Model;

public class MyGames {
    public int MyGameID;
    public int PlayingHour;
    public String GameID;
    public String UserID;

    public MyGames(int MyGameID, int PlayingHour, String GameID, String UserID) {
        this.MyGameID = MyGameID;
        this.PlayingHour = PlayingHour;
        this.GameID = GameID;
        this.UserID = UserID;
    }

    public int getMyGameID() {
        return MyGameID;
    }

    public int getPlayingHour() {
        return PlayingHour;
    }

    public String getGameID() {
        return GameID;
    }

    public String getUserID() {
        return UserID;
    }
}
