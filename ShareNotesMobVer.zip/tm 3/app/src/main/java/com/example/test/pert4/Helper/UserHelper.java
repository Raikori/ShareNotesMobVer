package com.example.test.pert4.Helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.example.test.pert4.Model.User;

import java.util.ArrayList;

public class UserHelper {

    private DatabaseHelper databaseHelper;
    private SQLiteDatabase sqLiteDatabase;

    public UserHelper(Context context) {
        this.context = context;
    }

    private Context context;

    public void open() throws SQLiteException{
        databaseHelper = new DatabaseHelper(context);
        sqLiteDatabase = databaseHelper.getReadableDatabase();
    }

    void close(){
        sqLiteDatabase.close();
    }

    public void insertData(User users){
        ContentValues contentValues = new ContentValues();
        contentValues.put("UserID", users.getUserID());
        contentValues.put("UserName", users.getUserName());
        contentValues.put("UserEmail", users.getUserEmail());
        contentValues.put("UserPassword", users.getUserPassword());
        contentValues.put("UserBirthday", users.getUserBirthday());
        contentValues.put("UserPhone", users.getUserPhone());
        contentValues.put("UserGender", users.getUserGender());
        contentValues.put("UserBalance", users.getUserBalance());
        contentValues.put("UserStatus", users.getUserStatus());

        sqLiteDatabase.insert("Users",null, contentValues);
    }

    public void deleteData(){
        sqLiteDatabase.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = 'Users'");
        sqLiteDatabase.delete("Users",null, null);
    }

    public User getUserData(String email, String password){
        String[] args = new String[]{email, password};

        Cursor cursor = sqLiteDatabase.query("Users", null, "UserEmail = ? AND UserPassword = ?",
                args, null, null, null,null);
        cursor.moveToFirst();
        if(cursor.getCount() > 0){
            User user = new User(
                    cursor.getString(cursor.getColumnIndexOrThrow("UserID")),
                    cursor.getString(cursor.getColumnIndexOrThrow("UserName")),
                    cursor.getString(cursor.getColumnIndexOrThrow("UserEmail")),
                    cursor.getString(cursor.getColumnIndexOrThrow("UserPassword")),
                    cursor.getString(cursor.getColumnIndexOrThrow("UserBirthday")),
                    cursor.getString(cursor.getColumnIndexOrThrow("UserPhone")),
                    cursor.getString(cursor.getColumnIndexOrThrow("UserGender")),
                    Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("UserBalance"))),
                    cursor.getString(cursor.getColumnIndexOrThrow("UserStatus"))
            );
            cursor.close();
            return user;
        }
        return null;
    }

    public ArrayList<User> getData(){
        ArrayList<User> users = new ArrayList<>();
        Cursor cursor = sqLiteDatabase.query("Users", null, null,
                null, null, null, null,null);
        cursor.moveToFirst();
        User user;

        if(cursor.getCount() > 0){
            do{
                user = new User(
                        cursor.getString(cursor.getColumnIndexOrThrow("UserID")),
                        cursor.getString(cursor.getColumnIndexOrThrow("UserName")),
                        cursor.getString(cursor.getColumnIndexOrThrow("UserEmail")),
                        cursor.getString(cursor.getColumnIndexOrThrow("UserPassword")),
                        cursor.getString(cursor.getColumnIndexOrThrow("UserBirthday")),
                        cursor.getString(cursor.getColumnIndexOrThrow("UserPhone")),
                        cursor.getString(cursor.getColumnIndexOrThrow("UserGender")),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("UserBalance"))),
                        cursor.getString(cursor.getColumnIndexOrThrow("UserStatus"))
                );

                users.add(user);
                cursor.moveToNext();
            }while(!cursor.isAfterLast());
        }
        cursor.close();
        return users;
    }
}
