package com.example.test.pert4.Helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper{

    private static String SQL_CREATE_TABLE_GAMES =
            String.format("CREATE TABLE %s (" +
                            "%s INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "%s TEXT NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s INTEGER NOT NULL, " +
                            "%s INTEGER NOT NULL)",
                    "Games", "GameID", "GameName", "GameDescription",
                    "GameGenre", "GameRating", "GameStock", "GamePrice");

    private static String SQL_CREATE_TABLE_USERS =
            String.format("CREATE TABLE %s (" +
                            "%s TEXT PRIMARY KEY NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s INTEGER NOT NULL, " +
                            "%s TEXT NOT NULL)",
                    "Users", "UserID", "UserName", "UserEmail", "UserPassword",
                    "UserBirthday", "UserPhone", "UserGender", "UserBalance",
                    "UserStatus");

    private static String SQL_CREATE_TABLE_MYGAMES =
            String.format("CREATE TABLE %s (" +
                            "%s INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "%s INTEGER NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "%s TEXT NOT NULL, " +
                            "FOREIGN KEY(GameID) REFERENCES Games(GameID)," +
                            "FOREIGN KEY(UserID) REFERENCES Users(UserID))",
                    "MyGames", "MyGameID", "PlayingHour", "GameID", "UserID");

    private static final int DB_VER = 1;
    DatabaseHelper(Context context){
        super(context, "GameCenter",null,DB_VER);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE_GAMES);
        db.execSQL(SQL_CREATE_TABLE_USERS);
        db.execSQL(SQL_CREATE_TABLE_MYGAMES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Games");
        db.execSQL("DROP TABLE IF EXISTS MyGames");
        db.execSQL("DROP TABLE IF EXISTS Users");
        onCreate(db);
    }
}

