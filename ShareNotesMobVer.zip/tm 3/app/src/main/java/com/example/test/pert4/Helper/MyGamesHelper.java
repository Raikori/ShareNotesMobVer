package com.example.test.pert4.Helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.example.test.pert4.Model.MyGames;
import com.example.test.pert4.Model.User;

import java.util.ArrayList;

public class MyGamesHelper {

    private DatabaseHelper databaseHelper;
    private SQLiteDatabase sqLiteDatabase;

    public MyGamesHelper(Context context) {
        this.context = context;
    }

    private Context context;

    public void open() throws SQLiteException{
        databaseHelper = new DatabaseHelper(context);
        sqLiteDatabase = databaseHelper.getReadableDatabase();
    }

    void close(){
        sqLiteDatabase.close();
    }

    public void insertData(MyGames myGames){
        ContentValues contentValues = new ContentValues();
        contentValues.put("PlayingHour", myGames.getPlayingHour());
        contentValues.put("GameID", myGames.getGameID());
        contentValues.put("UserID", myGames.getUserID());

        sqLiteDatabase.insert("MyGames",null, contentValues);
    }

    public void updateData(int myGamesID, int playHours){
        ContentValues contentValues = new ContentValues();
        contentValues.put("PlayingHour", playHours);

        sqLiteDatabase.update("MyGames",contentValues, "MyGameID = "+myGamesID, null);
    }

    public void deleteData(){
        sqLiteDatabase.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = 'MyGames'");
        sqLiteDatabase.delete("MyGames",null, null);
    }

    public ArrayList<MyGames> getData(String UserID){
        ArrayList<MyGames> myGames = new ArrayList<>();
        String[] args = new String[]{UserID};
        Cursor cursor = sqLiteDatabase.query("MyGames", null, "UserID = ?",
                args, null, null, null,null);
        cursor.moveToFirst();
        MyGames myGame;

        if(cursor.getCount() > 0){
            do{
                myGame = new MyGames(
                        Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("MyGameID"))),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("PlayingHour"))),
                        cursor.getString(cursor.getColumnIndexOrThrow("GameID")),
                        cursor.getString(cursor.getColumnIndexOrThrow("UserID"))
                );

                myGames.add(myGame);
                cursor.moveToNext();
            }while(!cursor.isAfterLast());
        }
        cursor.close();
        return myGames;
    }

    public int[] GetGameIDbyUserID(String UserID){
        String[] args = new String[]{UserID};
        Cursor cursor = sqLiteDatabase.query("MyGames", null, "UserID = ?",
                args, null, null, null,null);
        cursor.moveToFirst();
        MyGames myGame;
        int count = 0;
        int[] gameID = new int[cursor.getCount()];

        if(cursor.getCount() > 0){
            do{
                gameID[count] = Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("GameID")));
                cursor.moveToNext();
                count++;
            }while(!cursor.isAfterLast());
        }
        cursor.close();
        return gameID;
    }
}
