package com.example.test.pert4;

import android.app.ActionBar;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.test.pert4.Model.User;
import com.example.test.pert4.Repository.UsersRepository;

import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener{
    Button btnRegister;
    Spinner txtStatus;
    int year, month, day;
    String monthName, gender;
    RadioButton rdMale,rdFemale;
    UsersRepository usersRepository;
    static ArrayList<User> listUser = new ArrayList<User>();
    EditText txtName, txtEmail, txtPassword, txtConfPass, txtPhone, txtBdayDate, birthdayDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        usersRepository = new UsersRepository(this);

        birthdayDate = (EditText)findViewById(R.id.txtBdayDate);
        btnRegister = findViewById(R.id.btn_register);
        txtName = findViewById(R.id.txtName);
        txtEmail = findViewById(R.id.txtEmail);
        txtPassword = findViewById(R.id.txtPassword);
        txtConfPass = findViewById(R.id.txtConfPass);
        txtPhone = findViewById(R.id.txtPhone);
        txtBdayDate = findViewById(R.id.txtBdayDate);

        rdMale = findViewById(R.id.radioMale);
        rdFemale = findViewById(R.id.radioFemale);

        txtStatus = findViewById(R.id.txtStatus);

        //setOnClickListener
        birthdayDate.setOnClickListener(this);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtName.getText().toString().equals("") || txtEmail.getText().toString().equals("")
                        || txtEmail.getText().toString().equals("") || txtEmail.getText().toString().equals("")
                        || txtPassword.getText().toString().equals("") || txtConfPass.getText().toString().equals("")
                        || txtPhone.getText().toString().equals("") || txtBdayDate.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"All fields must be filled",Toast.LENGTH_SHORT).show();
        }else if(txtStatus.getSelectedItem().toString().equals("Please Select Status")){
                    Toast.makeText(getApplicationContext(),"Status must be selected",Toast.LENGTH_SHORT).show();
                }else if(txtName.getText().toString().length() < 3 || txtName.getText().toString().length() > 25){
                    Toast.makeText(getApplicationContext(),"Name must be between 3 and 25 characters",Toast.LENGTH_SHORT).show();
                }else if(txtPassword.getText().toString().length() < 6){
                    Toast.makeText(getApplicationContext(),"Password must be more than 6 characters",Toast.LENGTH_SHORT).show();
                }else if(!txtPassword.getText().toString().equals(txtConfPass.getText().toString())){
                    Toast.makeText(getApplicationContext(),"Confirmation password must be the same with the password input",Toast.LENGTH_SHORT).show();
                }else if(!Patterns.EMAIL_ADDRESS.matcher(txtEmail.getText().toString()).matches()){
                    Toast.makeText(getApplicationContext(),"Email must be filled with a valid email format",Toast.LENGTH_SHORT).show();
                }else if(txtPhone.getText().toString().length()  < 10 || txtPhone.getText().toString().length()  > 12){
                    Toast.makeText(getApplicationContext(),"Phone number must be between 10 and 12 digits",Toast.LENGTH_SHORT).show();
                }else if(!rdMale.isChecked() && !rdFemale.isChecked()){
                    Toast.makeText(RegisterActivity.this,"Please choose a gender",Toast.LENGTH_SHORT).show();
                }else{
                    String userID = generateUserID();

                    if(rdMale.isChecked()){
                        gender = "Male";
                    }
                    else{
                        gender = "Female";
                    }

                    usersRepository.insertData(new User(userID, txtName.getText().toString(), txtEmail.getText().toString(),
                            txtPassword.getText().toString(), txtBdayDate.getText().toString(), txtPhone.getText().toString(),  gender, 15000, txtStatus.getSelectedItem().toString()));
                    Toast.makeText(getApplicationContext(),"Success Register User with User ID : " + userID,Toast.LENGTH_SHORT).show();

                    finish();
                }

            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }


    String generateUserID(){
        int digit1= (int) (Math.random()*(9-0)+1);
        int digit2= (int) (Math.random()*(9-0)+1);
        int digit3= (int) (Math.random()*(9-0)+1);
        return digit1+""+digit2+""+digit3;
    }

    @Override
    public void onClick(View v) {
        final Calendar c = Calendar.getInstance();
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        monthName = new DateFormatSymbols().getMonths()[monthOfYear];
                        birthdayDate.setText(dayOfMonth + " " + monthName + " " + year);
                    }
                }, year, month, day);
        datePickerDialog.show();
    }

    public static ArrayList<User> getListUser() {
        return listUser;
    }
}
