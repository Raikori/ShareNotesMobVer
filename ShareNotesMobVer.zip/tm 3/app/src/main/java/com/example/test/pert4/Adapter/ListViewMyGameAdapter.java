package com.example.test.pert4.Adapter;

import android.content.Context;
import android.widget.ArrayAdapter;
import com.example.test.pert4.Model.MyGames;
import java.util.ArrayList;

public class ListViewMyGameAdapter extends ArrayAdapter<MyGames> {
    Context context;

    public ListViewMyGameAdapter(Context context, ArrayList<MyGames> listMyGame) {
        super(context, 0, listMyGame);
        this.context = context;
    }
}

