package com.example.test.pert4.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.example.test.pert4.Adapter.ListViewHomeAdapter;
import com.example.test.pert4.MasterActivity;
import com.example.test.pert4.Model.Game;
import com.example.test.pert4.Model.MyGames;
import com.example.test.pert4.Model.UserGame;
import com.example.test.pert4.R;
import com.example.test.pert4.Repository.GamesRepository;
import com.example.test.pert4.Repository.MyGamesRepository;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    ArrayList<UserGame> listUserGame = new ArrayList<UserGame>();
    TextView tvErrMsg, tvEmail, tvPhone, tvName;
    MyGamesRepository myGamesRepository;
    GamesRepository gamesRepository;
    ArrayList<MyGames> listMyGame;
    ArrayList<Game> listGame;
    ListViewHomeAdapter adapter;
    MasterActivity activity;
    ListView listView;
    View rootView;
    int[] gameID;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_home, container, false);

        listView = rootView.findViewById(R.id.fhomeGameList);
        activity = (MasterActivity) getActivity();
        myGamesRepository = new MyGamesRepository(activity);
        gamesRepository = new GamesRepository(activity);

        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        tvName = getView().findViewById(R.id.profileName);
        tvEmail = getView().findViewById(R.id.profileEmail);
        tvPhone = getView().findViewById(R.id.profilePhone);

        tvName.setText(activity.getLoginUserName());
        tvEmail.setText(activity.getLoginUserEmail());
        tvPhone.setText(activity.getLoginUserPhone());
    }

    @Override
    public void onResume(){
        super.onResume();

        gameID = myGamesRepository.getGameIDbyUserID(activity.getLoginUserID());
        listGame = gamesRepository.getListGameByGameID(gameID);
        listMyGame = myGamesRepository.getMyGamebyUserID(activity.getLoginUserID());

        for(int i=0;i<listGame.size();i++){
            listUserGame.add(new UserGame(listMyGame.get(i).getMyGameID(), listGame.get(i).gameName, listGame.get(i).desc, listGame.get(i).genre, Integer.toString(listMyGame.get(i).PlayingHour)));
        }
        tvErrMsg = getView().findViewById(R.id.errMsgHome);

        if(listGame.size() == 0){
            tvErrMsg.setVisibility(View.VISIBLE);
        }else{
            tvErrMsg.setVisibility(View.INVISIBLE);
            adapter = new ListViewHomeAdapter(rootView.getContext(), listUserGame);
            listView.setAdapter(adapter);
        }
    }
}
