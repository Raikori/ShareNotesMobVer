package com.example.test.pert4.Model;

public class User {
    public String UserID;
    public String UserName;
    public String UserEmail;
    public String UserPassword;
    public String UserBirthday;
    public String UserPhone;
    public String UserGender;
    public int UserBalance;
    public String UserStatus;


    public User(String UserID, String UserName, String UserEmail, String UserPassword, String UserBirthday,
                String UserPhone, String UserGender, int UserBalance, String UserStatus) {
        this.UserID = UserID;
        this.UserName = UserName;
        this.UserEmail = UserEmail;
        this.UserPassword = UserPassword;
        this.UserBirthday = UserBirthday;
        this.UserPhone = UserPhone;
        this.UserGender = UserGender;
        this.UserBalance = UserBalance;
        this.UserStatus = UserStatus;
    }

    public String getUserID() {
        return UserID;
    }

    public String getUserName() {
        return UserName;
    }

    public String getUserEmail() {
        return UserEmail;
    }

    public String getUserPassword() {
        return UserPassword;
    }

    public String getUserBirthday() {
        return UserBirthday;
    }

    public String getUserPhone() {
        return UserPhone;
    }

    public String getUserGender() {
        return UserGender;
    }

    public int getUserBalance() {
        return UserBalance;
    }

    public String getUserStatus() {
        return UserStatus;
    }
}
