package com.example.test.pert4.Model;

public class UserGame {
    public int MyGameID;
    public String GameName;
    public String GameGenre;
    public String GameDescription;
    public String PlayingHours;


    public UserGame(int MyGameID, String GameName, String GameGenre, String GameDescription, String PlayingHours) {
        this.MyGameID = MyGameID;
        this.GameName = GameName;
        this.GameGenre = GameGenre;
        this.GameDescription = GameDescription;
        this.PlayingHours = PlayingHours;
    }
}
