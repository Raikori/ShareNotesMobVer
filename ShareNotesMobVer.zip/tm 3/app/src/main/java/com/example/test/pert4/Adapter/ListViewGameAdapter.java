package com.example.test.pert4.Adapter;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.AppCompatRatingBar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.test.pert4.Fragment.GameDetailFragment;
import com.example.test.pert4.MasterActivity;
import com.example.test.pert4.Model.Game;
import com.example.test.pert4.R;

import java.util.ArrayList;

public class ListViewGameAdapter extends ArrayAdapter<Game> {
    GameDetailFragment gameDetailFragment;
    AppCompatRatingBar rbRating;
    Context context;
    TextView tvName;
    Bundle bundle;
    TextView tvDesc;

    public ListViewGameAdapter(Context context, ArrayList<Game> listGame) {
        super(context, 0, listGame);
            this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Game games = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_game_listview, parent, false);
        }

        tvName = convertView.findViewById(R.id.listDetail_gameName);
        tvDesc = convertView.findViewById(R.id.listDetail_desc);
        rbRating = convertView.findViewById(R.id.listDetail_ratbar);

        tvName.setText(games.gameName);
        tvDesc.setText(games.desc);
        rbRating.setRating(games.rating);

        convertView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                bundle = new Bundle();
                bundle.putString("gameID", String.valueOf(games.gameID));
                gameDetailFragment = new GameDetailFragment ();
                gameDetailFragment.setArguments(bundle);

                ((MasterActivity)context).getSupportFragmentManager().beginTransaction().replace(
                        R.id.fragment_container, gameDetailFragment,"gameDetailFragment"
                ).addToBackStack(null).commit();
            }
        });

        return convertView;
    }

}
