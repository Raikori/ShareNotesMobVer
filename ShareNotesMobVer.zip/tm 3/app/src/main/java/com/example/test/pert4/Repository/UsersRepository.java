package com.example.test.pert4.Repository;

import android.content.Context;
import android.os.AsyncTask;

import com.example.test.pert4.Helper.UserHelper;
import com.example.test.pert4.Model.User;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class UsersRepository {
    UserHelper userHelper;
    ArrayList<User> listUser = new ArrayList<User>();
    User user;

    public UsersRepository(Context context){
        userHelper = new UserHelper(context);
        userHelper.open();
    }

    class LoadUserData extends AsyncTask<Void, Void, ArrayList<User>> {

        @Override
        protected ArrayList<User> doInBackground(Void... voids) {
            return userHelper.getData();
        }

        @Override
        protected void onPostExecute(ArrayList<User> users) {
            super.onPostExecute(users);
        }
    }

    class GetUserData extends AsyncTask<String, Void, User> {

        @Override
        protected User doInBackground(String... strings) {
            return userHelper.getUserData(strings[0], strings[1]);
        }

        @Override
        protected void onPostExecute(User user) {
            super.onPostExecute(user);
        }
    }

    public void insertData(User user){
        userHelper.insertData(user);
    }

    public void deleteAllData(){
        userHelper.deleteData();
    }

    public ArrayList<User> getListUser() {
        try {
            listUser = new LoadUserData().execute().get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return listUser;
    }

    public User getUserData(String[] cekData) {
        try {
            user = new GetUserData().execute(cekData).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return user;
    }
}
