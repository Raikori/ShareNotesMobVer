package com.example.test.pert4;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.test.pert4.Model.User;
import com.example.test.pert4.Repository.GamesRepository;
import com.example.test.pert4.Repository.UsersRepository;
import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
    ArrayList<User> listUser = new ArrayList<User>();
    String[] cekData = new String[]{};
    GamesRepository gamesRepository;
    UsersRepository usersRepository;
    SharedPreferences sessionPref;
    EditText txtPassword, txtEmail;
    Button btnLogin;
    Intent intent;
    TextView here;
    int flag = 0;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        usersRepository = new UsersRepository(this);
        gamesRepository = new GamesRepository(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, 1);

        btnLogin = findViewById(R.id.btn_login);
        txtEmail = findViewById(R.id.txtEmail);
        txtPassword = findViewById(R.id.txtPassword);
        listUser = (ArrayList<User>) RegisterActivity.getListUser();
        here = findViewById(R.id.TV_Here);

        btnLogin.setOnClickListener(this);
        here.setOnClickListener(this);


        if(gamesRepository.countAllData() == 0)
            gamesRepository.insertData();
    }

    @Override
    public void onClick(View view) {
        if(view==btnLogin){
            if(txtEmail.getText().toString().equals("")){
                Toast.makeText(getApplicationContext(),"Email must be filled!",Toast.LENGTH_SHORT).show();
            }else if(txtPassword.getText().toString().equals("")){
                Toast.makeText(getApplicationContext(),"Password must be filled!",Toast.LENGTH_SHORT).show();
            }else if(txtPassword.getText().toString().equals("a") && txtEmail.getText().toString().equals("a")){
                flag = 1;
            }

            cekData = new String[]{txtEmail.getText().toString(), txtPassword.getText().toString()};
            user = usersRepository.getUserData(cekData);

            if(user != null){
                flag = 1;
            }

            if(flag == 0){
                Toast.makeText(getApplicationContext(),"User isn't registered!",Toast.LENGTH_SHORT).show();
            }else{
                flag = 0;

                sessionPref = getApplicationContext().getSharedPreferences("sessionPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = sessionPref.edit();
                editor.putString("UserID", user.getUserID());
                editor.putString("UserName", user.getUserName());
                editor.putString("UserEmail", user.getUserEmail());
                editor.putString("UserPhone", user.getUserPhone());
                editor.putInt("UserBalance", user.getUserBalance());
                editor.commit();

                intent = new Intent(LoginActivity.this, MasterActivity.class);
                startActivity(intent);
            }
        }
        else if(view==here){
            intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        }
    }
}
