package com.example.test.pert4.Helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.example.test.pert4.Model.Game;

import java.util.ArrayList;

public class GameHelper {

    private DatabaseHelper databaseHelper;
    private SQLiteDatabase sqLiteDatabase;

    public GameHelper(Context context) {
        this.context = context;
    }

    private Context context;

    public void open() throws SQLiteException{
        databaseHelper = new DatabaseHelper(context);
        sqLiteDatabase = databaseHelper.getReadableDatabase();
    }

    public void close(){
        sqLiteDatabase.close();
    }

    public void insertData(Game game){
        ContentValues contentValues = new ContentValues();
        contentValues.put("GameName", game.getGameName());
        contentValues.put("GameDescription", game.getDesc());
        contentValues.put("GameGenre", game.getGenre());
        contentValues.put("GameRating", Float.toString(game.getRating()));
        contentValues.put("GameStock", game.getStock());
        contentValues.put("GamePrice", game.getPrice());

        sqLiteDatabase.insert("Games",null, contentValues);
    }

    public void deleteData(){
        sqLiteDatabase.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = 'Games'");
        sqLiteDatabase.delete("Games",null, null);
    }

    public int countData() {
        String countQuery = "SELECT  * FROM Games";
        Cursor cursor = sqLiteDatabase.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public ArrayList<Game> getData(){
        ArrayList<Game> games = new ArrayList<>();
        Cursor cursor = sqLiteDatabase.query("Games", null, null,
                null, null, null, null,null);
        cursor.moveToFirst();
        Game game;

        if(cursor.getCount() > 0){
            do{
                game = new Game(
                        Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("GameID"))),
                        cursor.getString(cursor.getColumnIndexOrThrow("GameName")),
                        cursor.getString(cursor.getColumnIndexOrThrow("GameGenre")),
                        cursor.getString(cursor.getColumnIndexOrThrow("GameDescription")),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("GameStock"))),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("GamePrice"))),
                        Float.parseFloat(cursor.getString(cursor.getColumnIndexOrThrow("GameRating")))
                );

                games.add(game);
                cursor.moveToNext();
            }while(!cursor.isAfterLast());
        }
        cursor.close();
        return games;
    }

        public Game getDataByGameID(int gameID){
            String[] args = new String[]{Integer.toString(gameID)};
            Cursor cursor = sqLiteDatabase.query("Games", null, "GameID = ?",
                    args, null, null, null,null);
            cursor.moveToFirst();

            if(cursor.getCount() > 0){
                Game game;
                game = new Game(
                        Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("GameID"))),
                        cursor.getString(cursor.getColumnIndexOrThrow("GameName")),
                        cursor.getString(cursor.getColumnIndexOrThrow("GameGenre")),
                        cursor.getString(cursor.getColumnIndexOrThrow("GameDescription")),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("GameStock"))),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("GamePrice"))),
                        Float.parseFloat(cursor.getString(cursor.getColumnIndexOrThrow("GameRating")))
                );
                cursor.close();
                return game;
            }
            return null;
        }
}
