package com.example.test.pert4.Fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.test.pert4.Adapter.ListViewGameAdapter;
import com.example.test.pert4.MasterActivity;
import com.example.test.pert4.Model.Game;
import com.example.test.pert4.R;
import com.example.test.pert4.Repository.GamesRepository;

import java.util.ArrayList;

public class GameFragment extends Fragment {
    ArrayList<Game> listGame = new ArrayList<Game>();
    GamesRepository gamesRepository;
    ListViewGameAdapter adapter;
    MasterActivity activity;
    ListView listView;
    View rootView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_game, container, false);
        listView = rootView.findViewById(R.id.fgameGameList);
        activity = (MasterActivity) getActivity();
        gamesRepository = new GamesRepository(activity);

        listGame = gamesRepository.getListGame();

        adapter = new ListViewGameAdapter(rootView.getContext(), listGame);
        listView.setAdapter(adapter);

        return rootView;
    }
}
