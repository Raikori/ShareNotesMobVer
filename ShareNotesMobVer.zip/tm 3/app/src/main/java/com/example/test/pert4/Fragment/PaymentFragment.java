package com.example.test.pert4.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.test.pert4.MasterActivity;
import com.example.test.pert4.Model.Game;
import com.example.test.pert4.Model.MyGames;
import com.example.test.pert4.R;
import com.example.test.pert4.Repository.GamesRepository;
import com.example.test.pert4.Repository.MyGamesRepository;

import java.util.ArrayList;

public class PaymentFragment extends Fragment {
    ArrayList<Game> listGame = new ArrayList<Game>();
    MyGamesRepository myGamesRepository;
    GamesRepository gamesRepository;
    MasterActivity activity;
    SmsManager smsManager;
    ImageView imageView;
    String receiverNumber, senderNumber, paramGameID, userID, change;
    TextView paidMoney, tvPrice;
    MyGames myGames;
    View rootView;
    int[] gameID;
    int price;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_payment, container, false);
        activity = (MasterActivity) getActivity();
        paramGameID = this.getArguments().getString("gameID");
        userID = activity.getLoginUserID();
        gamesRepository = new GamesRepository(activity);
        myGamesRepository = new MyGamesRepository(activity);

        gameID = new int[]{Integer.parseInt(paramGameID)};
        listGame = gamesRepository.getListGameByGameID(gameID);

        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        imageView = getView().findViewById(R.id.payment_back);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });

        final Button button = getView().findViewById(R.id.payment_btn);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                price = listGame.get(0).getPrice();
                paidMoney = getView().findViewById(R.id.payment_paidMoney);

                if(Integer.parseInt(paidMoney.getText().toString()) < price){
                    Toast.makeText(getActivity(),"The money must be greater or equal to the game price.",Toast.LENGTH_SHORT).show();
                }else{
                    myGames = new MyGames(0, 0, paramGameID, userID);
                    myGamesRepository.insertData(myGames);

                    smsManager = SmsManager.getDefault();

                    receiverNumber = "15555215554";
                    senderNumber = "15555215554";
                    change = Integer.toString(Integer.parseInt(paidMoney.getText().toString())-price);
                    smsManager.sendTextMessage(receiverNumber, senderNumber,
                            "Your Transaction has been completed successfully, your change is "+change,
                            null, null);

                    getActivity().getSupportFragmentManager().beginTransaction().replace(
                            R.id.fragment_container, new HomeFragment(),"homeFragment"
                    ).addToBackStack(null).commit();
                }
            }
        });

        tvPrice = getView().findViewById(R.id.payment_realPrice);
        tvPrice.setText("Game Price : IDR " + String.valueOf(listGame.get(0).getPrice()));
    }
}
