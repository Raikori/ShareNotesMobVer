package com.example.test.pert4.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatRatingBar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.test.pert4.MasterActivity;
import com.example.test.pert4.Model.Game;
import com.example.test.pert4.R;
import com.example.test.pert4.Repository.GamesRepository;
import com.example.test.pert4.Repository.MyGamesRepository;

import java.util.ArrayList;

public class GameDetailFragment extends Fragment {
    TextView tvName, tvStock, tvPrice, tvGenre, tvDesc;
    ArrayList<Game> listGame = new ArrayList<Game>();
    MyGamesRepository myGamesRepository;
    GamesRepository gamesRepository;
    AppCompatRatingBar rbRating;
    MasterActivity activity;
    String paramGameID = "";
    ImageView imageView;
    View rootView;
    int[] gameID;
    Game game;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_game_detail, container, false);
        activity = (MasterActivity) getActivity();

        myGamesRepository = new MyGamesRepository(activity);
        gamesRepository = new GamesRepository(activity);
        paramGameID = this.getArguments().getString("gameID");

        gameID = new int[]{Integer.parseInt(paramGameID)};
        listGame = gamesRepository.getListGameByGameID(gameID);

        return inflater.inflate(R.layout.fragment_game_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        imageView = getView().findViewById(R.id.listgame_back);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });

        final Button button = getView().findViewById(R.id.listgame_btnPayment);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("gameID", String.valueOf(paramGameID));
                PaymentFragment paymentFragment = new PaymentFragment();
                paymentFragment.setArguments(bundle);

                getActivity().getSupportFragmentManager().beginTransaction().replace(
                        R.id.fragment_container, paymentFragment,"paymentFragment"
                ).addToBackStack(null).commit();
            }
        });

        game = listGame.get(0);

        tvName = getView().findViewById(R.id.listgame_name);
        tvStock = getView().findViewById(R.id.listgame_stock);
        tvPrice = getView().findViewById(R.id.listgame_price);
        tvGenre = getView().findViewById(R.id.listgame_genre);
        tvDesc = getView().findViewById(R.id.listgame_description);
        rbRating = getView().findViewById(R.id.listgame_ratbar);

        tvName.setText("Title : " + game.gameName);
        tvStock.setText("Stock : " + String.valueOf(game.stock));
        tvPrice.setText("Price : " + String.valueOf(game.price));
        tvGenre.setText("Genre : " + game.genre);
        tvDesc.setText("Description : " + game.desc);
        rbRating.setRating(game.rating);
    }
}
