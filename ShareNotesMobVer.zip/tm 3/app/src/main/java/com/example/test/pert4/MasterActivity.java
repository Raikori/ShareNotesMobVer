package com.example.test.pert4;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.example.test.pert4.Fragment.AboutUsFragment;
import com.example.test.pert4.Fragment.GameFragment;
import com.example.test.pert4.Fragment.HomeFragment;
import com.example.test.pert4.Model.Game;

import java.util.ArrayList;

public class MasterActivity extends AppCompatActivity {
    String loginUserID, loginUserPhone, loginUserEmail, loginUserName;
    NavigationView rightNavigationView, leftNavigationView;
    ActionBarDrawerToggle toggle;
    ArrayList<Game> gamesList;
    int loginUserBalance;
    DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_master);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final SharedPreferences sessionPref = getApplicationContext().getSharedPreferences("sessionPref", 0);
        loginUserID = sessionPref.getString("UserID", null);
        loginUserPhone = sessionPref.getString("UserPhone", null);
        loginUserEmail = sessionPref.getString("UserEmail", null);
        loginUserName = sessionPref.getString("UserName", null);
        loginUserBalance = sessionPref.getInt("UserBalance", 0);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        leftNavigationView = findViewById(R.id.nav_left_view);
        leftNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                switch (menuItem.getItemId()){
                            case R.id.nav_userprofile:
                                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                        new HomeFragment()).commit();
                                break;
                            case R.id.nav_games:
                                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                        new GameFragment()).commit();
                                break;
                            case R.id.nav_home:
                                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                        new HomeFragment()).commit();
                                break;
                            case R.id.nav_logout:
                                //clear session
                                SharedPreferences.Editor editor = sessionPref.edit();
                                editor.clear();
                                editor.commit();

                                Intent i = new Intent(MasterActivity.this, LoginActivity.class);
                                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(i);
                                break;
                        }
                menuItem.setChecked(true);
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        rightNavigationView = findViewById(R.id.nav_right_view);
        rightNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.nav_aboutus:
                        Intent intent =new Intent(MasterActivity.this,MapsActivity.class);
                        startActivity(intent);
                        break;
                }

                menuItem.setChecked(true);
                drawer.closeDrawer(GravityCompat.END); /*Important Line*/
                return true;
            }
        });

        if(savedInstanceState == null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    new HomeFragment()).commit();
            leftNavigationView.setCheckedItem(R.id.nav_home );
        }
    }



    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (drawer.isDrawerOpen(GravityCompat.END)) {  /*Closes the Appropriate Drawer*/
            drawer.closeDrawer(GravityCompat.END);
        } else {
            super.onBackPressed();
            System.exit(0);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.drawer_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here.
        int id = item.getItemId();

        if (id == R.id.action_openRight) {
            drawer.openDrawer(GravityCompat.END); /*Opens the Right Drawer*/
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public String getLoginUserID() {
        return loginUserID;
    }

    public String getLoginUserPhone() {
        return loginUserPhone;
    }

    public String getLoginUserEmail() {
        return loginUserEmail;
    }

    public String getLoginUserName() {
        return loginUserName;
    }

    public int getLoginUserBalance() {
        return loginUserBalance;
    }
}
