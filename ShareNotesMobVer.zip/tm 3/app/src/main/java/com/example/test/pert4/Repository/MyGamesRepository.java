package com.example.test.pert4.Repository;

import android.content.Context;
import android.os.AsyncTask;

import com.example.test.pert4.Helper.MyGamesHelper;
import com.example.test.pert4.Model.MyGames;
import com.example.test.pert4.Model.User;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MyGamesRepository {
    MyGamesHelper myGamesHelper;
    ArrayList<MyGames> listMyGame = new ArrayList<MyGames>();
    int[] gameID;

    public MyGamesRepository(Context context){
        myGamesHelper = new MyGamesHelper(context);
        myGamesHelper.open();
    }

    class LoadMyGameData extends AsyncTask<String, Void, ArrayList<MyGames>> {
        @Override
        protected ArrayList<MyGames> doInBackground(String... strings) {
            return myGamesHelper.getData(strings[0]);
        }

        @Override
        protected void onPostExecute(ArrayList<MyGames> myGames) {
            super.onPostExecute(myGames);
        }
    }

    class GetGameIDbyUserID extends AsyncTask<String, Void, int[]> {
        @Override
        protected int[] doInBackground(String... strings) {
            return myGamesHelper.GetGameIDbyUserID(strings[0]);
        }

        @Override
        protected void onPostExecute(int[] ints) {
            super.onPostExecute(ints);
        }
    }

    public void insertData(MyGames myGames){
        myGamesHelper.insertData(myGames);
    }

    public void updateData(int myGamesID, int playHours){
        myGamesHelper.updateData(myGamesID, playHours);
    }

    public void deleteAllData(){
        myGamesHelper.deleteData();
    }

    public ArrayList<MyGames> getMyGamebyUserID(String UserID) {
        try {
            listMyGame = new MyGamesRepository.LoadMyGameData().execute(UserID).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return listMyGame;
    }

    public int[] getGameIDbyUserID(String UserID) {
        try {
            gameID = new MyGamesRepository.GetGameIDbyUserID().execute(UserID).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return gameID;
    }
}
