package com.example.test.pert4.Model;

public class Game {
    public int gameID;
    public String gameName;
    public String genre;
    public String desc;
    public int stock;
    public int price;
    public float rating;


    public Game(int gameID, String gameName, String genre, String desc, int stock, int price, float rating) {
        this.gameID = gameID;
        this.gameName = gameName;
        this.genre = genre;
        this.desc = desc;
        this.stock = stock;
        this.price = price;
        this.rating = rating;
    }

    public String getGameName() {
        return gameName;
    }

    public String getGenre() {
        return genre;
    }

    public String getDesc() {
        return desc;
    }

    public int getStock() {
        return stock;
    }

    public int getPrice() {
        return price;
    }

    public float getRating() {
        return rating;
    }
}
