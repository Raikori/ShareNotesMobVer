package com.example.test.pert4.Repository;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.example.test.pert4.Helper.GameHelper;
import com.example.test.pert4.Helper.UserHelper;
import com.example.test.pert4.HttpHandler;
import com.example.test.pert4.LoginActivity;
import com.example.test.pert4.Model.Game;
import com.example.test.pert4.Model.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class GamesRepository {
    GameHelper gameHelper;
    ArrayList<Game> listGame = new ArrayList<Game>();
    ArrayList<Game> listGameByGameID = new ArrayList<Game>();

    public GamesRepository(Context context){
        gameHelper = new GameHelper(context);
        gameHelper.open();
    }

    class LoadGameData extends AsyncTask<Void, Void, ArrayList<Game>> {

        @Override
        protected ArrayList<Game> doInBackground(Void... voids) {
            return gameHelper.getData();
        }

        @Override
        protected void onPostExecute(ArrayList<Game> games) {
            super.onPostExecute(games);
            listGame = games;
        }
    }

    class InsertGameFromJSON extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            String url = "https://api.myjson.com/bins/15cfg8";
            String jsonStr = sh.makeServiceCall(url);

            if (jsonStr != null) {
                try {
                    JSONArray contacts = new JSONArray(jsonStr);
                    Game game;

                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);
                        String gameName = c.getString("name");
                        int price = Integer.parseInt(c.getString("price"));
                        int stock = Integer.parseInt(c.getString("stock"));
                        float rating = Float.parseFloat(c.getString("rating"));
                        String genre = c.getString("genre");
                        String desc = c.getString("description");

                        game = new Game(0, gameName, genre, desc, stock, price, rating);
                        gameHelper.insertData(game);
                    }
                } catch (final JSONException e) {}

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }
    }

    class LoadGameDataByGameID extends AsyncTask<int[], Void, ArrayList<Game>> {
        int[] tempgameid;

        public LoadGameDataByGameID(int[] gameids) {
            tempgameid = gameids;
        }

        @Override
        protected ArrayList<Game> doInBackground(int[]... ints) {
            int x = 0;
            ArrayList<Game> temp = new ArrayList<Game>();
            for(int i=0;i<tempgameid.length;i++){
                temp.add(gameHelper.getDataByGameID(tempgameid[i]));
            }

            return temp;
        }

        @Override
        protected void onPostExecute(ArrayList<Game> games) {
            super.onPostExecute(games);
            listGameByGameID = games;
        }
    }

    public void insertData(){
        new InsertGameFromJSON().execute();
    }

    public void deleteAllData(){
        gameHelper.deleteData();
    }

    public int countAllData(){
        return gameHelper.countData();
    }

    public ArrayList<Game> getListGame() {
        try {
            listGame = new LoadGameData().execute().get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return listGame;
    }

    public ArrayList<Game> getListGameByGameID(int[] gameID) {
        try {
            listGameByGameID = new LoadGameDataByGameID(gameID).execute().get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return listGameByGameID;
    }
}
